"""
Base class for forecasting models
"""
from abc import ABC, abstractmethod
import numpy as np
import pandas as pd
from typing import Optional


class BaseForecaster(ABC):
    """Base class for all forecasting models"""
    
    def __init__(self, name: str):
        self.name = name
        self.is_fitted = False
    
    @abstractmethod
    def fit(self, X, y, **kwargs):
        """Fit the model to training data"""
        pass
    
    @abstractmethod
    def predict(self, X, **kwargs):
        """Make predictions"""
        pass
    
    def forecast(self, X, horizon: int, **kwargs):
        """
        Forecast future values (multi-step ahead)
        
        Args:
            X: Input features
            horizon: Number of steps ahead to forecast
        
        Returns:
            Forecasted values
        """
        # Default: recursive prediction
        predictions = []
        current_X = X.copy()
        
        for _ in range(horizon):
            pred = self.predict(current_X, **kwargs)
            predictions.append(pred[0] if isinstance(pred, (list, np.ndarray)) else pred)
            # Update features for next step (simplified)
            # In practice, this should update lag features properly
        
        return np.array(predictions)




