"""
Traditional time series models (ARIMA, Prophet)
"""
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
from prophet import Prophet
from models.base_model import BaseForecaster
import warnings
warnings.filterwarnings('ignore')


class ARIMAForecaster(BaseForecaster):
    """ARIMA model for time series forecasting"""
    
    def __init__(self, order=(1, 1, 1), seasonal_order=(0, 0, 0, 0)):
        super().__init__("ARIMA")
        self.order = order
        self.seasonal_order = seasonal_order
        self.model = None
    
    def fit(self, y: pd.Series, **kwargs):
        """Fit ARIMA model"""
        try:
            self.model = ARIMA(y, order=self.order, seasonal_order=self.seasonal_order)
            self.fitted_model = self.model.fit()
            self.is_fitted = True
        except Exception as e:
            print(f"ARIMA fitting failed: {e}")
            # Fallback to simpler model
            self.order = (1, 0, 0)
            self.model = ARIMA(y, order=self.order)
            self.fitted_model = self.model.fit()
            self.is_fitted = True
    
    def predict(self, steps: int, **kwargs):
        """Predict future values"""
        if not self.is_fitted:
            raise ValueError("Model not fitted")
        
        forecast = self.fitted_model.forecast(steps=steps)
        return forecast.values if hasattr(forecast, 'values') else forecast
    
    def forecast(self, y: pd.Series, horizon: int, **kwargs):
        """Forecast future values"""
        if not self.is_fitted:
            self.fit(y)
        
        return self.predict(steps=horizon)


class ProphetForecaster(BaseForecaster):
    """Prophet model for time series forecasting"""
    
    def __init__(self, **prophet_params):
        super().__init__("Prophet")
        default_params = {
            'yearly_seasonality': True,
            'weekly_seasonality': True,
            'daily_seasonality': False,
            'seasonality_mode': 'additive',
        }
        default_params.update(prophet_params)
        self.prophet_params = default_params
        self.model = None
    
    def fit(self, y: pd.Series, **kwargs):
        """Fit Prophet model"""
        # Prepare data for Prophet
        df = pd.DataFrame({
            'ds': y.index,
            'y': y.values
        })
        
        self.model = Prophet(**self.prophet_params)
        self.model.fit(df)
        self.is_fitted = True
    
    def predict(self, periods: int, **kwargs):
        """Predict future values"""
        if not self.is_fitted:
            raise ValueError("Model not fitted")
        
        future = self.model.make_future_dataframe(periods=periods)
        forecast = self.model.predict(future)
        
        return forecast['yhat'].tail(periods).values
    
    def forecast(self, y: pd.Series, horizon: int, **kwargs):
        """Forecast future values"""
        if not self.is_fitted:
            self.fit(y)
        
        return self.predict(periods=horizon)




