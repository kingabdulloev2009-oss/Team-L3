"""
Deep learning models for time series forecasting
"""
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from typing import Optional
from models.base_model import BaseForecaster
import warnings
warnings.filterwarnings('ignore')


class TimeSeriesDataset(Dataset):
    """Dataset class for time series"""
    
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


class LSTMForecaster(BaseForecaster):
    """LSTM model for time series forecasting"""
    
    def __init__(self, input_size=1, hidden_size=128, num_layers=2, 
                 dropout=0.2, learning_rate=0.001, epochs=100, 
                 batch_size=32, patience=15, device='cpu'):
        super().__init__("LSTM")
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.dropout = dropout
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.batch_size = batch_size
        self.patience = patience
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        self.model = None
        self.scaler = None
    
    def _build_model(self, input_dim):
        """Build LSTM model"""
        class LSTMModel(nn.Module):
            def __init__(self, input_dim, hidden_size, num_layers, dropout):
                super().__init__()
                self.lstm = nn.LSTM(input_dim, hidden_size, num_layers, 
                                   dropout=dropout, batch_first=True)
                self.fc = nn.Linear(hidden_size, 1)
            
            def forward(self, x):
                lstm_out, _ = self.lstm(x)
                output = self.fc(lstm_out[:, -1, :])
                return output.squeeze()
        
        return LSTMModel(input_dim, self.hidden_size, self.num_layers, self.dropout)
    
    def _reshape_for_lstm(self, X):
        """Reshape data for LSTM (samples, timesteps, features)"""
        # If X is 2D, assume each row is a flattened sequence
        # Reshape to (samples, timesteps, features)
        if X.ndim == 2:
            # Try to infer timesteps from lookback window
            # For simplicity, reshape to (samples, 1, features)
            return X.reshape(X.shape[0], 1, X.shape[1])
        return X
    
    def fit(self, X, y, validation_data=None, **kwargs):
        """Fit LSTM model"""
        from sklearn.preprocessing import StandardScaler
        
        # Normalize features
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)
        
        # Reshape for LSTM
        X_reshaped = self._reshape_for_lstm(X_scaled)
        input_dim = X_reshaped.shape[-1]
        
        # Build model
        self.model = self._build_model(input_dim).to(self.device)
        
        # Prepare data
        train_dataset = TimeSeriesDataset(X_reshaped, y)
        train_loader = DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True)
        
        # Prepare validation data
        val_loader = None
        if validation_data is not None:
            X_val, y_val = validation_data
            X_val_scaled = self.scaler.transform(X_val)
            X_val_reshaped = self._reshape_for_lstm(X_val_scaled)
            val_dataset = TimeSeriesDataset(X_val_reshaped, y_val)
            val_loader = DataLoader(val_dataset, batch_size=self.batch_size, shuffle=False)
        
        # Training
        criterion = nn.MSELoss()
        optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        
        best_val_loss = float('inf')
        patience_counter = 0
        
        for epoch in range(self.epochs):
            # Training
            self.model.train()
            train_loss = 0
            for batch_X, batch_y in train_loader:
                batch_X = batch_X.to(self.device)
                batch_y = batch_y.to(self.device)
                
                optimizer.zero_grad()
                predictions = self.model(batch_X)
                loss = criterion(predictions, batch_y)
                loss.backward()
                optimizer.step()
                train_loss += loss.item()
            
            # Validation
            if val_loader is not None:
                self.model.eval()
                val_loss = 0
                with torch.no_grad():
                    for batch_X, batch_y in val_loader:
                        batch_X = batch_X.to(self.device)
                        batch_y = batch_y.to(self.device)
                        predictions = self.model(batch_X)
                        loss = criterion(predictions, batch_y)
                        val_loss += loss.item()
                
                val_loss /= len(val_loader)
                
                # Early stopping
                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    patience_counter = 0
                    # Save best model state
                    self.best_model_state = self.model.state_dict().copy()
                else:
                    patience_counter += 1
                    if patience_counter >= self.patience:
                        print(f"Early stopping at epoch {epoch+1}")
                        self.model.load_state_dict(self.best_model_state)
                        break
        
        self.is_fitted = True
    
    def predict(self, X, **kwargs):
        """Make predictions"""
        if not self.is_fitted:
            raise ValueError("Model not fitted")
        
        self.model.eval()
        X_scaled = self.scaler.transform(X)
        X_reshaped = self._reshape_for_lstm(X_scaled)
        X_tensor = torch.FloatTensor(X_reshaped).to(self.device)
        
        with torch.no_grad():
            predictions = self.model(X_tensor)
        
        return predictions.cpu().numpy()


class TransformerForecaster(BaseForecaster):
    """Transformer model for time series forecasting"""
    
    def __init__(self, input_size=1, d_model=64, nhead=4, num_layers=3,
                 dropout=0.1, learning_rate=0.001, epochs=100,
                 batch_size=32, patience=15, device='cpu'):
        super().__init__("Transformer")
        self.input_size = input_size
        self.d_model = d_model
        self.nhead = nhead
        self.num_layers = num_layers
        self.dropout = dropout
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.batch_size = batch_size
        self.patience = patience
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        self.model = None
        self.scaler = None
    
    def _build_model(self, input_dim):
        """Build Transformer model"""
        class TransformerModel(nn.Module):
            def __init__(self, input_dim, d_model, nhead, num_layers, dropout):
                super().__init__()
                self.input_projection = nn.Linear(input_dim, d_model)
                encoder_layer = nn.TransformerEncoderLayer(
                    d_model=d_model, nhead=nhead, dropout=dropout, batch_first=True
                )
                self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
                self.fc = nn.Linear(d_model, 1)
            
            def forward(self, x):
                x = self.input_projection(x)
                x = self.transformer(x)
                x = x[:, -1, :]  # Take last timestep
                output = self.fc(x)
                return output.squeeze()
        
        return TransformerModel(input_dim, self.d_model, self.nhead, 
                               self.num_layers, self.dropout)
    
    def _reshape_for_transformer(self, X):
        """Reshape data for Transformer"""
        if X.ndim == 2:
            return X.reshape(X.shape[0], 1, X.shape[1])
        return X
    
    def fit(self, X, y, validation_data=None, **kwargs):
        """Fit Transformer model"""
        from sklearn.preprocessing import StandardScaler
        
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)
        X_reshaped = self._reshape_for_transformer(X_scaled)
        input_dim = X_reshaped.shape[-1]
        
        self.model = self._build_model(input_dim).to(self.device)
        
        train_dataset = TimeSeriesDataset(X_reshaped, y)
        train_loader = DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True)
        
        val_loader = None
        if validation_data is not None:
            X_val, y_val = validation_data
            X_val_scaled = self.scaler.transform(X_val)
            X_val_reshaped = self._reshape_for_transformer(X_val_scaled)
            val_dataset = TimeSeriesDataset(X_val_reshaped, y_val)
            val_loader = DataLoader(val_dataset, batch_size=self.batch_size, shuffle=False)
        
        criterion = nn.MSELoss()
        optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        
        best_val_loss = float('inf')
        patience_counter = 0
        
        for epoch in range(self.epochs):
            self.model.train()
            train_loss = 0
            for batch_X, batch_y in train_loader:
                batch_X = batch_X.to(self.device)
                batch_y = batch_y.to(self.device)
                
                optimizer.zero_grad()
                predictions = self.model(batch_X)
                loss = criterion(predictions, batch_y)
                loss.backward()
                optimizer.step()
                train_loss += loss.item()
            
            if val_loader is not None:
                self.model.eval()
                val_loss = 0
                with torch.no_grad():
                    for batch_X, batch_y in val_loader:
                        batch_X = batch_X.to(self.device)
                        batch_y = batch_y.to(self.device)
                        predictions = self.model(batch_X)
                        loss = criterion(predictions, batch_y)
                        val_loss += loss.item()
                
                val_loss /= len(val_loader)
                
                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    patience_counter = 0
                    self.best_model_state = self.model.state_dict().copy()
                else:
                    patience_counter += 1
                    if patience_counter >= self.patience:
                        print(f"Early stopping at epoch {epoch+1}")
                        self.model.load_state_dict(self.best_model_state)
                        break
        
        self.is_fitted = True
    
    def predict(self, X, **kwargs):
        """Make predictions"""
        if not self.is_fitted:
            raise ValueError("Model not fitted")
        
        self.model.eval()
        X_scaled = self.scaler.transform(X)
        X_reshaped = self._reshape_for_transformer(X_scaled)
        X_tensor = torch.FloatTensor(X_reshaped).to(self.device)
        
        with torch.no_grad():
            predictions = self.model(X_tensor)
        
        return predictions.cpu().numpy()




