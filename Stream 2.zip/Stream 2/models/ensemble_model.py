"""
Ensemble model combining multiple forecasting approaches
"""
import numpy as np
import pandas as pd
from typing import List, Dict, Optional
from models.base_model import BaseForecaster


class EnsembleForecaster(BaseForecaster):
    """Ensemble of multiple forecasting models"""
    
    def __init__(self, models: List[BaseForecaster], weights: Optional[List[float]] = None):
        """
        Initialize ensemble
        
        Args:
            models: List of forecasting models
            weights: Optional weights for each model (default: equal weights)
        """
        super().__init__("Ensemble")
        self.models = models
        self.weights = weights if weights else [1.0 / len(models)] * len(models)
        
        if len(self.weights) != len(self.models):
            raise ValueError("Number of weights must match number of models")
    
    def fit(self, X, y, **kwargs):
        """Fit all models in the ensemble"""
        for model in self.models:
            model.fit(X, y, **kwargs)
        self.is_fitted = True
    
    def predict(self, X, **kwargs):
        """Make ensemble predictions"""
        if not self.is_fitted:
            raise ValueError("Models not fitted")
        
        predictions = []
        for model in self.models:
            pred = model.predict(X, **kwargs)
            predictions.append(pred)
        
        # Weighted average
        predictions = np.array(predictions)
        weighted_pred = np.average(predictions, axis=0, weights=self.weights)
        
        return weighted_pred
    
    def get_individual_predictions(self, X, **kwargs):
        """Get predictions from each model individually"""
        if not self.is_fitted:
            raise ValueError("Models not fitted")
        
        individual_preds = {}
        for i, model in enumerate(self.models):
            individual_preds[model.name] = model.predict(X, **kwargs)
        
        return individual_preds




