"""
Machine learning models for time series forecasting
"""
import numpy as np
import pandas as pd
from models.base_model import BaseForecaster

# Optional imports - models will be skipped if packages not available
try:
    from xgboost import XGBRegressor
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False

try:
    from catboost import CatBoostRegressor
    HAS_CATBOOST = True
except ImportError:
    HAS_CATBOOST = False

try:
    from lightgbm import LGBMRegressor
    HAS_LIGHTGBM = True
except ImportError:
    HAS_LIGHTGBM = False

try:
    from sklearn.ensemble import RandomForestRegressor
    HAS_RF = True
except ImportError:
    HAS_RF = False


class XGBoostForecaster(BaseForecaster):
    """XGBoost model for time series forecasting"""
    
    def __init__(self, **params):
        super().__init__("XGBoost")
        if not HAS_XGBOOST:
            raise ImportError("xgboost not installed. Install with: pip install xgboost")
        self.params = params
        self.model = None
    
    def fit(self, X, y, **kwargs):
        """Fit XGBoost model"""
        self.model = XGBRegressor(**self.params)
        self.model.fit(X, y)
        self.is_fitted = True
    
    def predict(self, X, **kwargs):
        """Make predictions"""
        if not self.is_fitted:
            raise ValueError("Model not fitted")
        return self.model.predict(X)


class CatBoostForecaster(BaseForecaster):
    """CatBoost model for time series forecasting"""
    
    def __init__(self, **params):
        super().__init__("CatBoost")
        if not HAS_CATBOOST:
            raise ImportError("catboost not installed. Install with: pip install catboost")
        self.params = params
        self.model = None
    
    def fit(self, X, y, **kwargs):
        """Fit CatBoost model"""
        self.model = CatBoostRegressor(**self.params)
        self.model.fit(X, y, verbose=False)
        self.is_fitted = True
    
    def predict(self, X, **kwargs):
        """Make predictions"""
        if not self.is_fitted:
            raise ValueError("Model not fitted")
        return self.model.predict(X)


class LightGBMForecaster(BaseForecaster):
    """LightGBM model for time series forecasting"""
    
    def __init__(self, **params):
        super().__init__("LightGBM")
        if not HAS_LIGHTGBM:
            raise ImportError("lightgbm not installed. Install with: pip install lightgbm")
        self.params = params
        self.model = None
    
    def fit(self, X, y, **kwargs):
        """Fit LightGBM model"""
        self.model = LGBMRegressor(**self.params, verbosity=-1)
        self.model.fit(X, y)
        self.is_fitted = True
    
    def predict(self, X, **kwargs):
        """Make predictions"""
        if not self.is_fitted:
            raise ValueError("Model not fitted")
        return self.model.predict(X)


class RandomForestForecaster(BaseForecaster):
    """Random Forest model for time series forecasting"""
    
    def __init__(self, n_estimators=100, max_depth=10, random_state=42):
        super().__init__("RandomForest")
        if not HAS_RF:
            raise ImportError("scikit-learn not installed. Install with: pip install scikit-learn")
        self.model = RandomForestRegressor(
            n_estimators=n_estimators,
            max_depth=max_depth,
            random_state=random_state,
            n_jobs=-1
        )
        self.is_fitted = False
    
    def fit(self, X, y, **kwargs):
        """Fit Random Forest model"""
        self.model.fit(X, y)
        self.is_fitted = True
    
    def predict(self, X, **kwargs):
        """Make predictions"""
        if not self.is_fitted:
            raise ValueError("Model not fitted")
        return self.model.predict(X)

