"""
Simple standalone data generator - minimal dependencies
"""
import os
import sys

# Test basic imports first
try:
    import csv
    import random
    from datetime import datetime, timedelta
    HAS_BASIC = True
except ImportError:
    HAS_BASIC = False

# Try advanced imports
try:
    import numpy as np
    import pandas as pd
    HAS_ADVANCED = True
except ImportError:
    HAS_ADVANCED = False

def create_data_simple():
    """Create data using only standard library"""
    print("Creating data using standard library only...")
    
    # Create directory
    data_dir = "data"
    os.makedirs(data_dir, exist_ok=True)
    
    # Generate dates
    start_date = datetime(2020, 1, 1)
    n_days = 1000
    dates = [start_date + timedelta(days=i) for i in range(n_days)]
    
    # Generate three series with simple random walk
    random.seed(42)
    
    def generate_series(n, start_value=100, trend=0.01, volatility=2):
        values = [start_value]
        for i in range(1, n):
            change = random.gauss(trend, volatility)
            new_value = values[-1] + change
            values.append(max(new_value, 1))  # Keep positive
        return values
    
    series1 = generate_series(n_days, 100, 0.02, 3)
    series2 = generate_series(n_days, 50, 0.01, 2)
    series3 = generate_series(n_days, 75, 0.015, 2.5)
    
    # Write to CSV
    output_path = os.path.join(data_dir, "train.csv")
    with open(output_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['date', 'series_1', 'series_2', 'series_3'])
        for i, date in enumerate(dates):
            writer.writerow([date.strftime('%Y-%m-%d'), 
                            f"{series1[i]:.2f}", 
                            f"{series2[i]:.2f}", 
                            f"{series3[i]:.2f}"])
    
    print(f"Data saved to {output_path}")
    print(f"Generated {n_days} days of data")
    return output_path

def create_data_pandas():
    """Create data using pandas/numpy if available"""
    print("Creating data using pandas/numpy...")
    
    import numpy as np
    import pandas as pd
    from pathlib import Path
    
    # Try to import DATA_DIR from config
    try:
        from config import DATA_DIR
    except ImportError:
        DATA_DIR = Path(__file__).parent / "data"
    
    np.random.seed(42)
    dates = pd.date_range(start='2020-01-01', periods=1000, freq='D')
    
    # Generate three series
    trend1 = np.linspace(100, 150, 1000)
    seasonal1 = 10 * np.sin(2 * np.pi * np.arange(1000) / 252)
    noise1 = np.random.normal(0, 5, 1000)
    series1 = trend1 + seasonal1 + noise1
    
    trend2 = np.linspace(50, 60, 1000)
    seasonal2 = 8 * np.sin(2 * np.pi * np.arange(1000) / 365)
    noise2 = np.random.normal(0, 3, 1000)
    series2 = trend2 + seasonal2 + noise2
    
    trend3 = np.linspace(75, 85, 1000)
    seasonal3 = 5 * np.sin(2 * np.pi * np.arange(1000) / 252)
    noise3 = np.random.normal(0, 2, 1000)
    series3 = trend3 + seasonal3 + noise3
    
    df = pd.DataFrame({
        'series_1': series1,
        'series_2': series2,
        'series_3': series3
    }, index=dates)
    
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    output_path = DATA_DIR / "train.csv"
    df.to_csv(output_path, index=True)
    
    print(f"Data saved to {output_path}")
    print(f"Shape: {df.shape}")
    return output_path

if __name__ == "__main__":
    try:
        print("="*60)
        print("Simple Data Generator")
        print("="*60)
        print()
        
        if not HAS_BASIC:
            print("ERROR: Cannot import standard library modules!")
            print("This should not happen. Check Python installation.")
            sys.exit(1)
        
        # Try pandas first, fallback to simple
        if HAS_ADVANCED:
            try:
                create_data_pandas()
                sys.exit(0)
            except Exception as e:
                print(f"Pandas method failed: {e}")
                print("Falling back to simple method...")
                print()
        
        # Use simple method
        create_data_simple()
        print()
        print("="*60)
        print("SUCCESS: Data file created!")
        print("="*60)
        sys.exit(0)
        
    except Exception as e:
        print()
        print("="*60)
        print("ERROR: Failed to create data")
        print("="*60)
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

