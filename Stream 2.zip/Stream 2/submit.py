"""
Submission handler for generating predictions on test data
"""
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, List, Optional
import argparse

from config import *
from pipeline import TimeSeriesPipeline
from utils.data_loader import load_data
from utils.feature_engineering import create_all_features, prepare_features_for_ml


def generate_predictions(pipeline: TimeSeriesPipeline, 
                        test_data_path: Path,
                        forecast_horizon: int = None,
                        model_name: str = 'ensemble',
                        output_path: Path = None) -> pd.DataFrame:
    """
    Generate predictions for test data
    
    Args:
        pipeline: Trained pipeline object
        test_data_path: Path to test data file
        forecast_horizon: Number of steps to forecast (uses config default if None)
        model_name: Name of model to use for predictions
        output_path: Path to save submission file
    
    Returns:
        DataFrame with predictions
    """
    if forecast_horizon is None:
        forecast_horizon = MODEL_CONFIG['forecast_horizon']
    
    print(f"Loading test data from {test_data_path}...")
    test_df = load_data(test_data_path)
    
    # Load models if not already loaded
    if not pipeline.models:
        print("Loading trained models...")
        pipeline.load_models()
    
    # Generate predictions for each series
    all_predictions = {}
    
    for series_name in pipeline.series_data.keys():
        if series_name not in pipeline.models:
            print(f"Warning: No models found for {series_name}, skipping...")
            continue
        
        print(f"\nGenerating predictions for {series_name}...")
        
        # Get training data to maintain feature consistency
        train_df = pipeline.series_data[series_name]
        target_col = train_df.columns[0]
        
        # Combine train and test for feature engineering
        # Note: In practice, test data might have different structure
        # This assumes test data has the same format as training data
        combined_df = pd.concat([train_df, test_df[[target_col]] if target_col in test_df.columns else test_df])
        
        # Create features
        df_features = create_all_features(combined_df, target_col, FEATURE_CONFIG)
        
        # Get the last window for prediction
        # In a real scenario, you'd need to properly handle the test period
        # For now, we'll use the last available data point
        X, y, _ = prepare_features_for_ml(
            df_features, target_col, MODEL_CONFIG['lookback_window']
        )
        
        if len(X) == 0:
            print(f"Warning: No valid features for {series_name}")
            continue
        
        # Use the last data point to start forecasting
        # For multi-step ahead, we'd need to recursively update features
        # This is a simplified version
        try:
            # Get predictions
            predictions = []
            
            # For single-step ahead, predict one step at a time
            # In practice, you might want to use the model's forecast method
            current_X = X[-1:].copy()
            
            # Simple approach: use last known values to predict
            # Better approach would be to recursively update features
            for step in range(min(forecast_horizon, len(test_df))):
                try:
                    pred = pipeline.predict(series_name, current_X, model_name=model_name)
                    if isinstance(pred, (list, np.ndarray)):
                        pred = pred[0] if len(pred) > 0 else np.nan
                    predictions.append(float(pred))
                    
                    # Update for next step (simplified - would need proper feature updating)
                    # For now, just use the same features
                except Exception as e:
                    print(f"Error at step {step}: {e}")
                    predictions.append(np.nan)
            
            # If we need more predictions, use the last prediction
            while len(predictions) < forecast_horizon:
                predictions.append(predictions[-1] if predictions else np.nan)
            
            all_predictions[series_name] = predictions[:forecast_horizon]
            
            print(f"  Generated {len(predictions)} predictions")
            
        except Exception as e:
            print(f"Error generating predictions for {series_name}: {e}")
            all_predictions[series_name] = [np.nan] * forecast_horizon
    
    # Create submission DataFrame
    submission = pd.DataFrame(all_predictions)
    
    # Add date index if test data has dates
    if isinstance(test_df.index, pd.DatetimeIndex):
        # Create date range for predictions
        if len(test_df) >= forecast_horizon:
            submission.index = test_df.index[:forecast_horizon]
        else:
            # Extend from last date
            last_date = test_df.index[-1]
            dates = pd.date_range(start=last_date + pd.Timedelta(days=1), periods=forecast_horizon, freq='D')
            submission.index = dates
    
    # Save submission
    if output_path is None:
        output_path = SUBMISSIONS_DIR / "submission.csv"
    
    output_path.parent.mkdir(exist_ok=True)
    submission.to_csv(output_path, index=True)
    print(f"\nSubmission saved to {output_path}")
    
    return submission


def main():
    """Main function for command-line usage"""
    parser = argparse.ArgumentParser(description="Generate predictions for test data")
    parser.add_argument("--test_data", type=str, required=True,
                       help="Path to test data file")
    parser.add_argument("--models_dir", type=str, default=None,
                       help="Path to trained models directory")
    parser.add_argument("--output", type=str, default=None,
                       help="Output path for submission file")
    parser.add_argument("--horizon", type=int, default=None,
                       help="Forecast horizon (number of steps)")
    parser.add_argument("--model", type=str, default='ensemble',
                       help="Model name to use for predictions")
    
    args = parser.parse_args()
    
    # Initialize pipeline
    pipeline = TimeSeriesPipeline()
    
    # Load models
    if args.models_dir:
        pipeline.load_models(Path(args.models_dir))
    else:
        pipeline.load_models()
    
    # Load training data (needed for feature engineering)
    # You might need to adjust this based on your data structure
    train_data_path = DATA_DIR / "train.csv"
    if train_data_path.exists():
        pipeline.load_and_prepare_data(train_data_path)
    
    # Generate predictions
    output_path = Path(args.output) if args.output else None
    submission = generate_predictions(
        pipeline,
        Path(args.test_data),
        forecast_horizon=args.horizon,
        model_name=args.model,
        output_path=output_path
    )
    
    print("\nSubmission file created successfully!")
    print(f"\nSubmission shape: {submission.shape}")
    print(f"\nFirst few rows:")
    print(submission.head())


if __name__ == "__main__":
    main()




