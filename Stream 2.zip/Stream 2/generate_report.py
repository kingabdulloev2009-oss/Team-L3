"""
Generate comprehensive report with results
"""
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime
import sys

from config import *
from pipeline import TimeSeriesPipeline
from utils.data_loader import load_data
from utils.evaluation import evaluate_series, calculate_metrics, print_metrics
from utils.feature_engineering import create_all_features, prepare_features_for_ml


def generate_report(data_path: Path = None, output_file: Path = None):
    """
    Generate comprehensive report with all results
    
    Args:
        data_path: Path to training data (None = use default)
        output_file: Path to save report (None = use default)
    """
    if data_path is None:
        data_path = DATA_DIR / "train.csv"
    
    if output_file is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = REPORTS_DIR / f"report_{timestamp}.txt"
    
    # Create reports directory
    REPORTS_DIR.mkdir(exist_ok=True)
    
    # Also create a "latest" report for easy access
    latest_file = REPORTS_DIR / "report_latest.txt"
    
    # Open file for writing
    with open(output_file, 'w', encoding='utf-8') as f:
        def write_line(text='', to_console=True):
            """Write line to both file and console"""
            print(text)
            f.write(text + '\n')
            f.flush()
        
        write_line("="*80)
        write_line("TIME SERIES FORECASTING - COMPREHENSIVE RESULTS REPORT")
        write_line("="*80)
        write_line(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        write_line("="*80)
        write_line()
        
        # Check if data exists
        if not data_path.exists():
            write_line(f"ERROR: Training data not found at {data_path}")
            write_line("Please create training data first or run generate_sample_data.py")
            return output_file
        
        # Initialize pipeline
        write_line("Initializing pipeline...")
        pipeline = TimeSeriesPipeline()
        
        # Load data
        write_line(f"\nLoading data from: {data_path}")
        try:
            pipeline.load_and_prepare_data(data_path)
            write_line(f"[OK] Successfully loaded {len(pipeline.series_data)} time series")
        except Exception as e:
            write_line(f"ERROR loading data: {e}")
            return output_file
        
        # Display data summary
        write_line("\n" + "="*80)
        write_line("DATA SUMMARY")
        write_line("="*80)
        for name, df in pipeline.series_data.items():
            write_line(f"\nSeries: {name}")
            write_line(f"  Shape: {df.shape[0]} rows, {df.shape[1]} columns")
            write_line(f"  Date range: {df.index.min()} to {df.index.max()}")
            write_line(f"  Duration: {len(df)} days")
            write_line(f"  Mean: {df.iloc[:, 0].mean():.4f}")
            write_line(f"  Std: {df.iloc[:, 0].std():.4f}")
            write_line(f"  Min: {df.iloc[:, 0].min():.4f}")
            write_line(f"  Max: {df.iloc[:, 0].max():.4f}")
            write_line(f"  Missing values: {df.isnull().sum().sum()}")
        
        # Train models and evaluate
        write_line("\n" + "="*80)
        write_line("MODEL TRAINING AND EVALUATION")
        write_line("="*80)
        
        all_results = {}
        overall_results = {
            'series': [],
            'model': [],
            'r2_score': [],
            'mae': [],
            'rmse': [],
            'mape': []
        }
        
        for series_name, df in pipeline.series_data.items():
            write_line(f"\n{'='*80}")
            write_line(f"Processing Series: {series_name}")
            write_line(f"{'='*80}")
            
            try:
                # Prepare features
                write_line(f"\nPreparing features for {series_name}...")
                target_col = df.columns[0]
                X, y = pipeline.prepare_features(series_name, df, target_col)
                write_line(f"  [OK] Created {X.shape[1]} features from {len(df)} data points")
                write_line(f"  [OK] Generated {len(X)} training samples (lookback={pipeline.config['lookback_window']})")
                
                # Split data
                split_idx = int(len(X) * (1 - pipeline.config['validation_split']))
                X_train, X_val = X[:split_idx], X[split_idx:]
                y_train, y_val = y[:split_idx], y[split_idx:]
                
                write_line(f"  Training samples: {len(X_train)}")
                write_line(f"  Validation samples: {len(X_val)}")
                
                # Train models
                write_line(f"\nTraining models for {series_name}...")
                pipeline.train_models(series_name, X_train, y_train, X_val, y_val)
                
                # Evaluate models
                write_line(f"\nEvaluating models on validation set...")
                results = pipeline.evaluate_all_models(series_name, X_val, y_val)
                all_results[series_name] = results
                
                # Extract and display metrics
                write_line(f"\nResults for {series_name}:")
                write_line("-" * 80)
                write_line(f"{'Model':<20} {'R² Score':<12} {'MAE':<12} {'RMSE':<12} {'MAPE':<12}")
                write_line("-" * 80)
                
                for model_name, metrics in results.items():
                    r2_key = f"{series_name}_{model_name}_r2_score"
                    mae_key = f"{series_name}_{model_name}_mae"
                    rmse_key = f"{series_name}_{model_name}_rmse"
                    mape_key = f"{series_name}_{model_name}_mape"
                    
                    r2 = metrics.get(r2_key, 0)
                    mae = metrics.get(mae_key, 0)
                    rmse = metrics.get(rmse_key, 0)
                    mape = metrics.get(mape_key, 0)
                    
                    write_line(f"{model_name:<20} {r2:<12.4f} {mae:<12.2f} {rmse:<12.2f} {mape:<12.2f}")
                    
                    # Store for summary
                    overall_results['series'].append(series_name)
                    overall_results['model'].append(model_name)
                    overall_results['r2_score'].append(r2)
                    overall_results['mae'].append(mae)
                    overall_results['rmse'].append(rmse)
                    overall_results['mape'].append(mape)
                
                # Find best model
                best_model = max(results.items(), 
                               key=lambda x: x[1].get(f"{series_name}_{x[0]}_r2_score", float('-inf')))
                best_model_name, best_metrics = best_model
                best_r2 = best_metrics.get(f"{series_name}_{best_model_name}_r2_score", 0)
                write_line(f"\n  Best model: {best_model_name} (R² = {best_r2:.4f})")
                
            except Exception as e:
                write_line(f"ERROR processing {series_name}: {e}")
                import traceback
                write_line(traceback.format_exc())
                continue
        
        # Overall Summary
        write_line("\n" + "="*80)
        write_line("OVERALL SUMMARY")
        write_line("="*80)
        
        if overall_results['series']:
            summary_df = pd.DataFrame(overall_results)
            
            # Best model per series
            write_line("\nBest Model per Series:")
            write_line("-" * 80)
            for series in summary_df['series'].unique():
                series_df = summary_df[summary_df['series'] == series]
                best_idx = series_df['r2_score'].idxmax()
                best_row = series_df.loc[best_idx]
                write_line(f"  {series}: {best_row['model']} (R² = {best_row['r2_score']:.4f})")
            
            # Aggregate across all series
            write_line("\nAggregated Performance (across all series):")
            write_line("-" * 80)
            
            # Group by model and average
            model_summary = summary_df.groupby('model').agg({
                'r2_score': 'mean',
                'mae': 'mean',
                'rmse': 'mean',
                'mape': 'mean'
            }).sort_values('r2_score', ascending=False)
            
            write_line(f"\n{'Model':<20} {'Avg R² Score':<15} {'Avg MAE':<15} {'Avg RMSE':<15} {'Avg MAPE':<15}")
            write_line("-" * 80)
            for model, row in model_summary.iterrows():
                write_line(f"{model:<20} {row['r2_score']:<15.4f} {row['mae']:<15.2f} "
                          f"{row['rmse']:<15.2f} {row['mape']:<15.2f}")
            
            # Overall best model
            best_overall_model = model_summary.index[0]
            best_overall_r2 = model_summary.iloc[0]['r2_score']
            write_line(f"\n[OK] Best overall model: {best_overall_model} (Avg R² = {best_overall_r2:.4f})")
        
        # Save models
        write_line("\n" + "="*80)
        write_line("SAVING MODELS")
        write_line("="*80)
        try:
            pipeline.save_models()
            write_line(f"[OK] Models saved to {MODELS_DIR}")
        except Exception as e:
            write_line(f"ERROR saving models: {e}")
        
        # Configuration summary
        write_line("\n" + "="*80)
        write_line("CONFIGURATION SUMMARY")
        write_line("="*80)
        write_line(f"Forecast horizon: {MODEL_CONFIG['forecast_horizon']} days")
        write_line(f"Lookback window: {MODEL_CONFIG['lookback_window']} days")
        write_line(f"Validation split: {MODEL_CONFIG['validation_split']*100:.0f}%")
        write_line(f"Random seed: {MODEL_CONFIG['random_seed']}")
        write_line(f"\nFeatures:")
        write_line(f"  Lag features: {FEATURE_CONFIG.get('lags', [])}")
        write_line(f"  Rolling windows: {FEATURE_CONFIG.get('rolling_windows', [])}")
        write_line(f"  Technical indicators: {FEATURE_CONFIG.get('technical_indicators', False)}")
        write_line(f"  Seasonality: {FEATURE_CONFIG.get('seasonality', False)}")
        
        # Final statistics
        write_line("\n" + "="*80)
        write_line("FINAL STATISTICS")
        write_line("="*80)
        total_models = sum(len(models) for models in pipeline.models.values())
        write_line(f"Total series processed: {len(pipeline.series_data)}")
        write_line(f"Total models trained: {total_models}")
        write_line(f"Report saved to: {output_file}")
        
        write_line("\n" + "="*80)
        write_line("REPORT GENERATION COMPLETE")
        write_line("="*80)
    
    # Copy to latest file
    try:
        import shutil
        shutil.copy2(output_file, latest_file)
    except Exception as e:
        print(f"Note: Could not create latest report copy: {e}")
    
    return output_file


if __name__ == "__main__":
    # Parse command line arguments
    data_path = None
    output_file = None
    
    if len(sys.argv) > 1:
        data_path = Path(sys.argv[1])
    if len(sys.argv) > 2:
        output_file = Path(sys.argv[2])
    
    try:
        report_file = generate_report(data_path, output_file)
        print(f"\n[SUCCESS] Report generated successfully: {report_file}")
    except Exception as e:
        print(f"\n[ERROR] Error generating report: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

