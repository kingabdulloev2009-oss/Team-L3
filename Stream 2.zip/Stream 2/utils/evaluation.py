"""
Evaluation metrics and utilities
"""
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from typing import Dict, List


def calculate_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """
    Calculate evaluation metrics
    
    Args:
        y_true: True values
        y_pred: Predicted values
    
    Returns:
        Dictionary of metrics
    """
    metrics = {
        'r2_score': r2_score(y_true, y_pred),
        'mae': mean_absolute_error(y_true, y_pred),
        'rmse': np.sqrt(mean_squared_error(y_true, y_pred)),
        'mape': np.mean(np.abs((y_true - y_pred) / (y_true + 1e-8))) * 100,
    }
    
    return metrics


def evaluate_series(y_true: pd.Series, y_pred: pd.Series, series_name: str = "") -> Dict[str, float]:
    """
    Evaluate predictions for a single series
    
    Args:
        y_true: True values
        y_pred: Predicted values
        series_name: Name of the series
    
    Returns:
        Dictionary of metrics
    """
    if len(y_true) != len(y_pred):
        raise ValueError(f"Length mismatch: {len(y_true)} vs {len(y_pred)}")
    
    # Convert to numpy arrays
    y_true_arr = np.array(y_true)
    y_pred_arr = np.array(y_pred)
    
    metrics = calculate_metrics(y_true_arr, y_pred_arr)
    
    if series_name:
        metrics = {f'{series_name}_{k}': v for k, v in metrics.items()}
    
    return metrics


def evaluate_multiple_series(y_true_dict: Dict[str, pd.Series], 
                            y_pred_dict: Dict[str, pd.Series]) -> Dict[str, float]:
    """
    Evaluate predictions across multiple series
    
    Args:
        y_true_dict: Dictionary of {series_name: true_values}
        y_pred_dict: Dictionary of {series_name: predicted_values}
    
    Returns:
        Dictionary of aggregated metrics
    """
    all_metrics = {}
    individual_metrics = {}
    
    # Evaluate each series individually
    for series_name in y_true_dict.keys():
        if series_name not in y_pred_dict:
            raise ValueError(f"Missing predictions for series: {series_name}")
        
        series_metrics = evaluate_series(
            y_true_dict[series_name],
            y_pred_dict[series_name],
            series_name
        )
        individual_metrics.update(series_metrics)
    
    # Aggregate across all series
    all_true = np.concatenate([y_true_dict[name].values for name in y_true_dict.keys()])
    all_pred = np.concatenate([y_pred_dict[name].values for name in y_pred_dict.keys()])
    
    aggregated_metrics = calculate_metrics(all_true, all_pred)
    aggregated_metrics = {f'aggregated_{k}': v for k, v in aggregated_metrics.items()}
    
    all_metrics.update(individual_metrics)
    all_metrics.update(aggregated_metrics)
    
    return all_metrics


def print_metrics(metrics: Dict[str, float], title: str = "Evaluation Metrics"):
    """
    Print metrics in a formatted way
    
    Args:
        metrics: Dictionary of metrics
        title: Title for the output
    """
    print(f"\n{'='*60}")
    print(f"{title}")
    print(f"{'='*60}")
    
    for key, value in metrics.items():
        if 'r2_score' in key:
            print(f"{key:30s}: {value:8.4f}")
        elif 'mape' in key:
            print(f"{key:30s}: {value:8.2f}%")
        else:
            print(f"{key:30s}: {value:8.2f}")
    
    print(f"{'='*60}\n")




