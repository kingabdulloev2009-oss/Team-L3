"""
Feature engineering for time series
"""
import pandas as pd
import numpy as np
from typing import List, Optional


def create_lag_features(df: pd.DataFrame, target_col: str, lags: List[int]) -> pd.DataFrame:
    """
    Create lag features for time series
    
    Args:
        df: DataFrame with time series
        target_col: Name of target column
        lags: List of lag periods
    
    Returns:
        DataFrame with lag features added
    """
    df = df.copy()
    for lag in lags:
        df[f'{target_col}_lag_{lag}'] = df[target_col].shift(lag)
    return df


def create_rolling_features(df: pd.DataFrame, target_col: str, windows: List[int]) -> pd.DataFrame:
    """
    Create rolling statistical features
    
    Args:
        df: DataFrame with time series
        target_col: Name of target column
        windows: List of window sizes
    
    Returns:
        DataFrame with rolling features added
    """
    df = df.copy()
    for window in windows:
        rolling = df[target_col].rolling(window=window, min_periods=1)
        df[f'{target_col}_rolling_mean_{window}'] = rolling.mean()
        df[f'{target_col}_rolling_std_{window}'] = rolling.std()
        df[f'{target_col}_rolling_min_{window}'] = rolling.min()
        df[f'{target_col}_rolling_max_{window}'] = rolling.max()
        
        # Ratio features
        df[f'{target_col}_ratio_mean_{window}'] = df[target_col] / (df[f'{target_col}_rolling_mean_{window}'] + 1e-8)
    
    return df


def create_technical_indicators(df: pd.DataFrame, target_col: str) -> pd.DataFrame:
    """
    Create technical indicators (moving averages, RSI, MACD, etc.)
    
    Args:
        df: DataFrame with time series
        target_col: Name of target column
    
    Returns:
        DataFrame with technical indicators added
    """
    df = df.copy()
    price = df[target_col]
    
    # Simple Moving Averages
    df[f'{target_col}_sma_7'] = price.rolling(7).mean()
    df[f'{target_col}_sma_14'] = price.rolling(14).mean()
    df[f'{target_col}_sma_30'] = price.rolling(30).mean()
    df[f'{target_col}_sma_60'] = price.rolling(60).mean()
    
    # Exponential Moving Averages
    df[f'{target_col}_ema_7'] = price.ewm(span=7, adjust=False).mean()
    df[f'{target_col}_ema_14'] = price.ewm(span=14, adjust=False).mean()
    df[f'{target_col}_ema_30'] = price.ewm(span=30, adjust=False).mean()
    
    # RSI (Relative Strength Index)
    delta = price.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / (loss + 1e-8)
    df[f'{target_col}_rsi'] = 100 - (100 / (1 + rs))
    
    # MACD
    ema_12 = price.ewm(span=12, adjust=False).mean()
    ema_26 = price.ewm(span=26, adjust=False).mean()
    df[f'{target_col}_macd'] = ema_12 - ema_26
    df[f'{target_col}_macd_signal'] = df[f'{target_col}_macd'].ewm(span=9, adjust=False).mean()
    df[f'{target_col}_macd_hist'] = df[f'{target_col}_macd'] - df[f'{target_col}_macd_signal']
    
    # Bollinger Bands
    bb_window = 20
    bb_std = price.rolling(bb_window).std()
    df[f'{target_col}_bb_upper'] = price.rolling(bb_window).mean() + (bb_std * 2)
    df[f'{target_col}_bb_lower'] = price.rolling(bb_window).mean() - (bb_std * 2)
    df[f'{target_col}_bb_width'] = df[f'{target_col}_bb_upper'] - df[f'{target_col}_bb_lower']
    df[f'{target_col}_bb_position'] = (price - df[f'{target_col}_bb_lower']) / (df[f'{target_col}_bb_width'] + 1e-8)
    
    # Price change features
    df[f'{target_col}_pct_change_1'] = price.pct_change(1)
    df[f'{target_col}_pct_change_7'] = price.pct_change(7)
    df[f'{target_col}_pct_change_30'] = price.pct_change(30)
    
    # Volatility
    df[f'{target_col}_volatility_7'] = price.pct_change().rolling(7).std()
    df[f'{target_col}_volatility_30'] = price.pct_change().rolling(30).std()
    
    return df


def create_seasonal_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create seasonal/time-based features
    
    Args:
        df: DataFrame with datetime index
    
    Returns:
        DataFrame with seasonal features added
    """
    df = df.copy()
    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index)
    
    df['day_of_week'] = df.index.dayofweek
    df['day_of_month'] = df.index.day
    df['week_of_year'] = df.index.isocalendar().week
    df['month'] = df.index.month
    df['quarter'] = df.index.quarter
    
    # Cyclical encoding
    df['day_of_week_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
    df['day_of_week_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
    df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
    df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
    
    return df


def create_all_features(df: pd.DataFrame, target_col: str, config: dict) -> pd.DataFrame:
    """
    Create all features based on configuration
    
    Args:
        df: DataFrame with time series
        target_col: Name of target column
        config: Feature configuration dictionary
    
    Returns:
        DataFrame with all features added
    """
    df = df.copy()
    
    # Lag features
    if 'lags' in config:
        df = create_lag_features(df, target_col, config['lags'])
    
    # Rolling features
    if 'rolling_windows' in config:
        df = create_rolling_features(df, target_col, config['rolling_windows'])
    
    # Technical indicators
    if config.get('technical_indicators', False):
        df = create_technical_indicators(df, target_col)
    
    # Seasonal features
    if config.get('seasonality', False):
        df = create_seasonal_features(df)
    
    return df


def prepare_features_for_ml(df: pd.DataFrame, target_col: str, lookback_window: int = 60):
    """
    Prepare features for machine learning models
    
    Args:
        df: DataFrame with features
        target_col: Name of target column
        lookback_window: Number of historical points to use
    
    Returns:
        X, y arrays for ML models
    """
    # Drop rows with NaN (from lag features)
    df_clean = df.dropna()
    
    if len(df_clean) < lookback_window + 1:
        raise ValueError(f"Not enough data: {len(df_clean)} < {lookback_window + 1}")
    
    # Prepare features (exclude target)
    feature_cols = [col for col in df_clean.columns if col != target_col]
    
    X_list = []
    y_list = []
    
    for i in range(lookback_window, len(df_clean)):
        X_list.append(df_clean[feature_cols].iloc[i-lookback_window:i].values.flatten())
        y_list.append(df_clean[target_col].iloc[i])
    
    X = np.array(X_list)
    y = np.array(y_list)
    
    return X, y, feature_cols




