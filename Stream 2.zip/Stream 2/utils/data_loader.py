"""
Data loading and preprocessing utilities
"""
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')


def load_data(data_path: Path, expected_columns: list = None):
    """
    Load time series data from CSV file
    
    Args:
        data_path: Path to CSV file
        expected_columns: Expected column names (optional)
    
    Returns:
        DataFrame with time series data
    """
    df = pd.read_csv(data_path)
    
    # Automatically detect date column
    date_cols = df.select_dtypes(include=['datetime64']).columns.tolist()
    if len(date_cols) == 0:
        # Try to parse common date column names
        for col in ['date', 'Date', 'DATE', 'timestamp', 'time', 'Time']:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col])
                date_cols = [col]
                break
    
    if len(date_cols) == 0 and df.index.name in ['date', 'Date', 'DATE']:
        df.index = pd.to_datetime(df.index)
        date_cols = [df.index.name]
    
    # Set date as index if found
    if len(date_cols) > 0:
        df.set_index(date_cols[0], inplace=True)
        df.index.name = 'date'
    
    # Ensure numeric columns
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) == 0:
        raise ValueError("No numeric columns found in data")
    
    df = df[numeric_cols]
    
    # Sort by date
    df.sort_index(inplace=True)
    
    return df


def validate_data(df: pd.DataFrame, min_length: int = 100):
    """
    Validate time series data
    
    Args:
        df: DataFrame to validate
        min_length: Minimum required length
    
    Returns:
        bool: True if valid
    """
    if len(df) < min_length:
        raise ValueError(f"Data too short: {len(df)} < {min_length}")
    
    if df.isnull().sum().sum() > 0:
        print(f"Warning: {df.isnull().sum().sum()} missing values found")
    
    return True


def split_temporal_data(df: pd.DataFrame, test_size: float = 0.2):
    """
    Split time series data temporally
    
    Args:
        df: DataFrame with time series
        test_size: Fraction of data for testing
    
    Returns:
        train_df, test_df
    """
    split_idx = int(len(df) * (1 - test_size))
    train_df = df.iloc[:split_idx].copy()
    test_df = df.iloc[split_idx:].copy()
    
    return train_df, test_df




