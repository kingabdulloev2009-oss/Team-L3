"""
Visualization utilities for time series forecasting
"""
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Optional
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Set style
try:
    plt.style.use('seaborn-v0_8-darkgrid')
except OSError:
    try:
        plt.style.use('seaborn-darkgrid')
    except OSError:
        plt.style.use('ggplot')
sns.set_palette("husl")


def plot_forecast(y_train: pd.Series, y_test: pd.Series, 
                 y_pred: pd.Series, title: str = "Forecast",
                 save_path: Optional[Path] = None):
    """
    Plot training data, test data, and predictions
    
    Args:
        y_train: Training time series
        y_test: Test time series
        y_pred: Predicted values
        title: Plot title
        save_path: Optional path to save figure
    """
    fig, ax = plt.subplots(figsize=(14, 6))
    
    # Plot training data
    ax.plot(y_train.index, y_train.values, label='Training Data', 
            color='blue', alpha=0.7, linewidth=1.5)
    
    # Plot test data
    ax.plot(y_test.index, y_test.values, label='True Values', 
            color='green', alpha=0.7, linewidth=1.5)
    
    # Plot predictions
    ax.plot(y_test.index, y_pred.values, label='Predictions', 
            color='red', alpha=0.7, linewidth=1.5, linestyle='--')
    
    ax.set_xlabel('Date', fontsize=12)
    ax.set_ylabel('Value', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.legend(loc='best', fontsize=10)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    
    plt.show()


def plot_interactive_forecast(y_train: pd.Series, y_test: pd.Series,
                             y_pred: pd.Series, title: str = "Forecast",
                             save_path: Optional[Path] = None):
    """
    Create interactive plotly visualization
    
    Args:
        y_train: Training time series
        y_test: Test time series
        y_pred: Predicted values
        title: Plot title
        save_path: Optional path to save HTML
    """
    fig = go.Figure()
    
    # Training data
    fig.add_trace(go.Scatter(
        x=y_train.index,
        y=y_train.values,
        mode='lines',
        name='Training Data',
        line=dict(color='blue', width=2)
    ))
    
    # Test data
    fig.add_trace(go.Scatter(
        x=y_test.index,
        y=y_test.values,
        mode='lines',
        name='True Values',
        line=dict(color='green', width=2)
    ))
    
    # Predictions
    fig.add_trace(go.Scatter(
        x=y_test.index,
        y=y_pred.values,
        mode='lines',
        name='Predictions',
        line=dict(color='red', width=2, dash='dash')
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title='Date',
        yaxis_title='Value',
        hovermode='x unified',
        template='plotly_white',
        width=1200,
        height=600
    )
    
    if save_path:
        fig.write_html(str(save_path))
    
    fig.show()


def plot_residuals(y_true: pd.Series, y_pred: pd.Series, 
                   title: str = "Residuals Analysis",
                   save_path: Optional[Path] = None):
    """
    Plot residual analysis
    
    Args:
        y_true: True values
        y_pred: Predicted values
        title: Plot title
        save_path: Optional path to save figure
    """
    residuals = y_true - y_pred
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # Residuals over time
    axes[0, 0].plot(y_true.index, residuals, alpha=0.7)
    axes[0, 0].axhline(y=0, color='r', linestyle='--')
    axes[0, 0].set_title('Residuals Over Time')
    axes[0, 0].set_xlabel('Date')
    axes[0, 0].set_ylabel('Residuals')
    axes[0, 0].grid(True, alpha=0.3)
    
    # Residuals histogram
    axes[0, 1].hist(residuals, bins=50, edgecolor='black', alpha=0.7)
    axes[0, 1].set_title('Residuals Distribution')
    axes[0, 1].set_xlabel('Residuals')
    axes[0, 1].set_ylabel('Frequency')
    axes[0, 1].grid(True, alpha=0.3)
    
    # Q-Q plot
    from scipy import stats
    stats.probplot(residuals, dist="norm", plot=axes[1, 0])
    axes[1, 0].set_title('Q-Q Plot')
    axes[1, 0].grid(True, alpha=0.3)
    
    # Residuals vs Predicted
    axes[1, 1].scatter(y_pred, residuals, alpha=0.5)
    axes[1, 1].axhline(y=0, color='r', linestyle='--')
    axes[1, 1].set_title('Residuals vs Predicted')
    axes[1, 1].set_xlabel('Predicted Values')
    axes[1, 1].set_ylabel('Residuals')
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.suptitle(title, fontsize=14, fontweight='bold')
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    
    plt.show()


def plot_model_comparison(results: Dict[str, Dict], 
                         metric: str = 'r2_score',
                         save_path: Optional[Path] = None):
    """
    Plot comparison of different models
    
    Args:
        results: Dictionary of {model_name: {metric: value}}
        metric: Metric to compare
        save_path: Optional path to save figure
    """
    model_names = list(results.keys())
    metric_values = [results[name].get(metric, 0) for name in model_names]
    
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.barh(model_names, metric_values, alpha=0.7)
    
    # Color bars based on performance
    colors = plt.cm.RdYlGn(np.linspace(0.3, 1, len(bars)))
    for bar, color in zip(bars, colors):
        bar.set_color(color)
    
    ax.set_xlabel(metric.replace('_', ' ').title(), fontsize=12)
    ax.set_title(f'Model Comparison: {metric.replace("_", " ").title()}', 
                 fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='x')
    
    # Add value labels
    for i, (name, value) in enumerate(zip(model_names, metric_values)):
        ax.text(value, i, f' {value:.4f}', va='center')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    
    plt.show()

