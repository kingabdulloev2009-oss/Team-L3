"""
Utilities for time series forecasting
"""




