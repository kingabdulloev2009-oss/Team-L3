"""
Configuration file for time series forecasting project
"""
import os
from pathlib import Path

# Project paths
PROJECT_ROOT = Path(__file__).parent
DATA_DIR = PROJECT_ROOT / "data"
MODELS_DIR = PROJECT_ROOT / "models"
SUBMISSIONS_DIR = PROJECT_ROOT / "submissions"
FIGURES_DIR = PROJECT_ROOT / "figures"
REPORTS_DIR = PROJECT_ROOT / "reports"

# Create directories
for dir_path in [DATA_DIR, MODELS_DIR, SUBMISSIONS_DIR, FIGURES_DIR, REPORTS_DIR]:
    dir_path.mkdir(exist_ok=True)

# Data configuration
TRAIN_DATA_PATH = DATA_DIR / "train.csv"
TEST_DATA_PATH = DATA_DIR / "test.csv"

# Model configuration
MODEL_CONFIG = {
    'forecast_horizon': 252,  # ~1 year ahead (trading days)
    'validation_split': 0.2,
    'lookback_window': 60,  # Number of past days to use for prediction
    'random_seed': 42,
}

# Feature engineering
FEATURE_CONFIG = {
    'lags': [1, 2, 3, 5, 7, 14, 21, 30, 60],  # Lag features
    'rolling_windows': [7, 14, 30, 60, 90],  # Rolling statistics windows
    'technical_indicators': True,
    'seasonality': True,
}

# Model hyperparameters (will be tuned via cross-validation)
MODEL_PARAMS = {
    'xgboost': {
        'n_estimators': 1000,
        'max_depth': 6,
        'learning_rate': 0.01,
        'subsample': 0.8,
        'colsample_bytree': 0.8,
        'random_state': 42,
    },
    'catboost': {
        'iterations': 1000,
        'depth': 6,
        'learning_rate': 0.01,
        'random_seed': 42,
        'verbose': False,
    },
    'lightgbm': {
        'n_estimators': 1000,
        'max_depth': 6,
        'learning_rate': 0.01,
        'subsample': 0.8,
        'random_state': 42,
    },
    'lstm': {
        'units': 128,
        'dropout': 0.2,
        'epochs': 100,
        'batch_size': 32,
        'patience': 15,
    },
    'transformer': {
        'd_model': 64,
        'nhead': 4,
        'num_layers': 3,
        'dropout': 0.1,
        'epochs': 100,
        'batch_size': 32,
        'patience': 15,
    },
}

# Evaluation metrics
METRICS = ['r2_score', 'mae', 'rmse', 'mape']




