"""
Main training pipeline for time series forecasting
"""
import numpy as np
import pandas as pd
from pathlib import Path
import joblib
from typing import Dict, List, Optional

from config import *
from utils.data_loader import load_data, validate_data, split_temporal_data
from utils.feature_engineering import create_all_features, prepare_features_for_ml
from utils.evaluation import evaluate_series, evaluate_multiple_series, print_metrics
# Visualization imports are optional
try:
    from utils.visualization import plot_forecast, plot_residuals, plot_model_comparison
    HAS_VISUALIZATION = True
except ImportError:
    HAS_VISUALIZATION = False

# Import models (with optional imports)
try:
    from models.ml_models import XGBoostForecaster, CatBoostForecaster, LightGBMForecaster, RandomForestForecaster
    HAS_ML_MODELS = True
except ImportError as e:
    print(f"Warning: Some ML models not available: {e}")
    HAS_ML_MODELS = False
    # Create dummy classes
    XGBoostForecaster = CatBoostForecaster = LightGBMForecaster = None
    try:
        from models.ml_models import RandomForestForecaster
    except ImportError:
        RandomForestForecaster = None

try:
    from models.traditional_models import ARIMAForecaster, ProphetForecaster
    HAS_TRADITIONAL = True
except ImportError:
    HAS_TRADITIONAL = False
    ARIMAForecaster = ProphetForecaster = None

try:
    from models.deep_learning_models import LSTMForecaster, TransformerForecaster
    HAS_DL_MODELS = True
except ImportError:
    HAS_DL_MODELS = False
    LSTMForecaster = TransformerForecaster = None

from models.ensemble_model import EnsembleForecaster


class TimeSeriesPipeline:
    """Main pipeline for time series forecasting"""
    
    def __init__(self, config: dict = None):
        """
        Initialize pipeline
        
        Args:
            config: Configuration dictionary (uses default from config.py if None)
        """
        self.config = config or MODEL_CONFIG
        self.feature_config = FEATURE_CONFIG
        self.models = {}
        self.predictions = {}
        self.metrics = {}
        
    def load_and_prepare_data(self, data_path: Path, series_columns: Optional[List[str]] = None):
        """
        Load and prepare data
        
        Args:
            data_path: Path to data file
            series_columns: List of column names for each series (None = auto-detect)
        
        Returns:
            Dictionary of {series_name: DataFrame}
        """
        print("Loading data...")
        df = load_data(data_path)
        validate_data(df)
        
        # Detect series columns
        if series_columns is None:
            # Assume each numeric column is a separate series
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            series_columns = numeric_cols if len(numeric_cols) > 0 else [df.columns[0]]
        
        self.series_data = {}
        for col in series_columns:
            if col in df.columns:
                self.series_data[col] = df[[col]]
            else:
                print(f"Warning: Column {col} not found in data")
        
        print(f"Loaded {len(self.series_data)} time series")
        return self.series_data
    
    def prepare_features(self, series_name: str, df: pd.DataFrame, target_col: str = None):
        """
        Prepare features for a single series
        
        Args:
            series_name: Name of the series
            df: DataFrame with time series
            target_col: Target column name (default: first column)
        
        Returns:
            X, y arrays for training
        """
        if target_col is None:
            target_col = df.columns[0]
        
        # Create features
        df_features = create_all_features(df, target_col, self.feature_config)
        
        # Prepare for ML
        X, y, feature_cols = prepare_features_for_ml(
            df_features, target_col, self.config['lookback_window']
        )
        
        # Store feature columns for later use
        if not hasattr(self, 'feature_columns'):
            self.feature_columns = {}
        self.feature_columns[series_name] = feature_cols
        
        return X, y
    
    def train_models(self, series_name: str, X_train, y_train, X_val=None, y_val=None):
        """
        Train multiple models for a series
        
        Args:
            series_name: Name of the series
            X_train: Training features
            y_train: Training targets
            X_val: Validation features (optional)
            y_val: Validation targets (optional)
        """
        print(f"\nTraining models for series: {series_name}")
        
        if series_name not in self.models:
            self.models[series_name] = {}
        
        # Initialize models (only use available ones)
        models_to_train = {}
        
        if XGBoostForecaster is not None:
            try:
                models_to_train['xgboost'] = XGBoostForecaster(**MODEL_PARAMS['xgboost'])
            except (ImportError, TypeError):
                pass
        
        if CatBoostForecaster is not None:
            try:
                models_to_train['catboost'] = CatBoostForecaster(**MODEL_PARAMS['catboost'])
            except (ImportError, TypeError):
                pass
        
        if LightGBMForecaster is not None:
            try:
                models_to_train['lightgbm'] = LightGBMForecaster(**MODEL_PARAMS['lightgbm'])
            except (ImportError, TypeError):
                pass
        
        if RandomForestForecaster is not None:
            try:
                models_to_train['random_forest'] = RandomForestForecaster(n_estimators=200, max_depth=15)
            except (ImportError, TypeError):
                pass
        
        # Add deep learning models if data is sufficient and available
        if len(X_train) > 100:
            if LSTMForecaster is not None:
                try:
                    models_to_train['lstm'] = LSTMForecaster(**MODEL_PARAMS['lstm'])
                except (ImportError, TypeError):
                    pass
            
            if TransformerForecaster is not None:
                try:
                    models_to_train['transformer'] = TransformerForecaster(**MODEL_PARAMS['transformer'])
                except (ImportError, TypeError):
                    pass
        
        # Train each model
        if len(models_to_train) == 0:
            print("  [WARNING] No models available to train!")
            print("  Install dependencies: pip install scikit-learn xgboost catboost lightgbm")
            return
        
        for model_name, model in models_to_train.items():
            print(f"  Training {model_name}...")
            try:
                if model_name in ['lstm', 'transformer']:
                    val_data = (X_val, y_val) if X_val is not None else None
                    model.fit(X_train, y_train, validation_data=val_data)
                else:
                    model.fit(X_train, y_train)
                
                self.models[series_name][model_name] = model
                print(f"    [OK] {model_name} trained successfully")
            except ImportError as e:
                print(f"    [SKIPPED] {model_name} - missing dependency: {e}")
            except Exception as e:
                print(f"    [FAILED] {model_name} training failed: {e}")
        
        # Create ensemble
        if len(self.models[series_name]) > 0:
            print("  Creating ensemble...")
            try:
                ensemble_models = list(self.models[series_name].values())
                # Weight better performing models more (simple heuristic)
                weights = [1.0] * len(ensemble_models)
                ensemble = EnsembleForecaster(ensemble_models, weights)
                ensemble.fit(X_train, y_train)
                self.models[series_name]['ensemble'] = ensemble
                print(f"    [OK] Ensemble created with {len(ensemble_models)} models")
            except Exception as e:
                print(f"    [WARNING] Ensemble creation failed: {e}")
                print(f"    Continuing with {len(self.models[series_name])} individual models")
        else:
            print("  [ERROR] No models trained! Cannot create ensemble.")
    
    def predict(self, series_name: str, X, model_name: str = 'ensemble'):
        """
        Make predictions for a series
        
        Args:
            series_name: Name of the series
            X: Features
            model_name: Name of model to use
        
        Returns:
            Predictions
        """
        if series_name not in self.models:
            raise ValueError(f"No models found for series: {series_name}")
        
        if model_name not in self.models[series_name]:
            raise ValueError(f"Model {model_name} not found for series {series_name}")
        
        model = self.models[series_name][model_name]
        return model.predict(X)
    
    def evaluate_all_models(self, series_name: str, X_test, y_test):
        """
        Evaluate all models for a series
        
        Args:
            series_name: Name of the series
            X_test: Test features
            y_test: Test targets
        
        Returns:
            Dictionary of metrics for each model
        """
        if series_name not in self.models:
            raise ValueError(f"No models found for series: {series_name}")
        
        results = {}
        for model_name, model in self.models[series_name].items():
            try:
                y_pred = model.predict(X_test)
                metrics = evaluate_series(
                    pd.Series(y_test),
                    pd.Series(y_pred),
                    f"{series_name}_{model_name}"
                )
                results[model_name] = metrics
            except Exception as e:
                print(f"Error evaluating {model_name}: {e}")
        
        return results
    
    def save_models(self, output_dir: Path = None):
        """Save trained models"""
        if output_dir is None:
            output_dir = MODELS_DIR
        
        output_dir.mkdir(exist_ok=True)
        
        for series_name, models_dict in self.models.items():
            series_dir = output_dir / series_name
            series_dir.mkdir(exist_ok=True)
            
            for model_name, model in models_dict.items():
                model_path = series_dir / f"{model_name}.pkl"
                try:
                    joblib.dump(model, model_path)
                except Exception as e:
                    print(f"Could not save {series_name}/{model_name}: {e}")
        
        print(f"Models saved to {output_dir}")
    
    def load_models(self, models_dir: Path = None):
        """Load trained models"""
        if models_dir is None:
            models_dir = MODELS_DIR
        
        for series_dir in models_dir.iterdir():
            if series_dir.is_dir():
                series_name = series_dir.name
                self.models[series_name] = {}
                
                for model_file in series_dir.glob("*.pkl"):
                    model_name = model_file.stem
                    model = joblib.load(model_file)
                    self.models[series_name][model_name] = model
        
        print(f"Models loaded from {models_dir}")


def run_pipeline(data_path: Path, output_dir: Path = None, 
                 series_columns: Optional[List[str]] = None,
                 save_models: bool = True):
    """
    Run the complete forecasting pipeline
    
    Args:
        data_path: Path to training data
        output_dir: Output directory for results
        series_columns: List of series column names
        save_models: Whether to save trained models
    
    Returns:
        Pipeline object with trained models and results
    """
    # Initialize pipeline
    pipeline = TimeSeriesPipeline()
    
    # Load data
    pipeline.load_and_prepare_data(data_path, series_columns)
    
    # Train models for each series
    all_metrics = {}
    
    for series_name, df in pipeline.series_data.items():
        print(f"\n{'='*60}")
        print(f"Processing Series: {series_name}")
        print(f"{'='*60}")
        
        # Prepare features
        target_col = df.columns[0]
        X, y = pipeline.prepare_features(series_name, df, target_col)
        
        # Split train/validation
        split_idx = int(len(X) * (1 - pipeline.config['validation_split']))
        X_train, X_val = X[:split_idx], X[split_idx:]
        y_train, y_val = y[:split_idx], y[split_idx:]
        
        print(f"Training samples: {len(X_train)}, Validation samples: {len(X_val)}")
        
        # Train models
        pipeline.train_models(series_name, X_train, y_train, X_val, y_val)
        
        # Evaluate on validation set
        print("\nEvaluating models on validation set...")
        val_metrics = pipeline.evaluate_all_models(series_name, X_val, y_val)
        all_metrics[series_name] = val_metrics
        
        # Print best model
        best_model = max(val_metrics.items(), 
                        key=lambda x: x[1].get(list(x[1].keys())[0], float('-inf')))
        print(f"\nBest model on validation: {best_model[0]}")
    
    # Save models
    if save_models:
        pipeline.save_models()
    
    # Print summary
    print(f"\n{'='*60}")
    print("PIPELINE SUMMARY")
    print(f"{'='*60}")
    for series_name, metrics_dict in all_metrics.items():
        print(f"\n{series_name}:")
        for model_name, metrics in metrics_dict.items():
            r2 = metrics.get(f"{series_name}_{model_name}_r2_score", 0)
            print(f"  {model_name:20s}: R² = {r2:.4f}")
    
    return pipeline

