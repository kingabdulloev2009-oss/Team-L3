# Time Series Forecasting for Anonymized Equities

A comprehensive solution for forecasting anonymized time series data representing public equities. This project implements multiple forecasting approaches and ensemble methods to achieve robust generalization across different assets and time periods.

## 🚀 Quick Start

**Easiest way to run:**
1. Double-click `RUN_ME.bat`
2. Wait for completion (5-10 minutes)
3. Check `reports/report_latest.txt` for results

**What happens:**
- Automatically detects Python
- Installs required packages
- Creates sample data (if needed)
- Trains models
- Generates comprehensive report

## 📋 Features

- **Multiple Model Types**: ARIMA, Prophet, XGBoost, CatBoost, LightGBM, Random Forest, LSTM, Transformer
- **Ensemble Approach**: Combines all models for improved robustness
- **Comprehensive Feature Engineering**: Lags, rolling statistics, technical indicators, seasonal features
- **Automatic Pipeline**: End-to-end automation
- **Evaluation Metrics**: R² (primary), MAE, RMSE, MAPE
- **Full Documentation**: See `DOCUMENTATION.md` for details

## 📁 Project Structure

```
├── RUN_ME.bat                 # Main execution file (auto-installs & runs)
├── pipeline.py                # Core pipeline class
├── generate_report.py         # Report generator
├── submit.py                  # Submission handler
├── config.py                  # Configuration
├── create_simple_data.py      # Sample data generator
├── train.ipynb                # Interactive notebook
│
├── models/                    # Model implementations
│   ├── base_model.py
│   ├── traditional_models.py
│   ├── ml_models.py
│   ├── deep_learning_models.py
│   └── ensemble_model.py
│
├── utils/                     # Utilities
│   ├── data_loader.py
│   ├── feature_engineering.py
│   ├── evaluation.py
│   └── visualization.py
│
├── data/                      # Data directory
├── reports/                   # Generated reports
├── models/                    # Saved models
└── requirements.txt          # Dependencies
```

## 💻 Installation

### Automatic (Recommended)
Just run `RUN_ME.bat` - it handles everything!

### Manual
```bash
pip install -r requirements.txt
```

## 📖 Usage

### Quick Run
```bash
# Windows
RUN_ME.bat

# Python
python generate_report.py
```

### Custom Usage
```python
from pipeline import TimeSeriesPipeline
from pathlib import Path

pipeline = TimeSeriesPipeline()
pipeline.load_and_prepare_data(Path("data/train.csv"))
# Models train automatically per series
```

## 📊 Data Format

CSV file with:
- Date column (auto-detected) or datetime index
- One or more numeric columns (each is a time series)

Example:
```csv
date,series_1,series_2,series_3
2020-01-01,100.5,50.2,75.8
2020-01-02,101.2,50.5,76.1
...
```

## 🎯 Evaluation

Models are evaluated using:
- **R² Score** (Primary): Coefficient of determination
- **MAE**: Mean Absolute Error
- **RMSE**: Root Mean Squared Error
- **MAPE**: Mean Absolute Percentage Error

## 📚 Documentation

- **Full Documentation**: See `DOCUMENTATION.md`
- **Methodology**: See `METHODOLOGY.md`
- **Presentation (Russian)**: See `PRESENTATION_RU.md`

## 🔧 Configuration

Edit `config.py` to customize:
- Forecast horizon
- Lookback window
- Feature engineering options
- Model hyperparameters

## 🐛 Troubleshooting

**Python not found:**
- Install Python from python.org
- Check "Add Python to PATH" during installation
- Try editing `RUN_ME.bat` to use `py` instead of `python`

**Missing dependencies:**
- Run: `pip install -r requirements.txt`
- Or use `RUN_ME.bat` which auto-installs

**Data generation fails:**
- Check Python: `python --version`
- Install: `pip install numpy pandas`
- Check write permissions

**Models not training:**
- Install: `pip install scikit-learn`
- Ensure data file exists: `data/train.csv`
- Need minimum ~100 data points

## 📄 License

This project is provided for educational and competition purposes.

## 🙏 Acknowledgments

Built using scikit-learn, XGBoost, CatBoost, LightGBM, PyTorch, Prophet, and other open-source libraries.

---

**For detailed information, see `DOCUMENTATION.md`**
