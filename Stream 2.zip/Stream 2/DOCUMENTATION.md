# Time Series Forecasting Project - Complete Documentation

## Table of Contents
1. [Project Overview](#project-overview)
2. [Installation Guide](#installation-guide)
3. [Quick Start](#quick-start)
4. [Project Structure](#project-structure)
5. [Usage Guide](#usage-guide)
6. [Configuration](#configuration)
7. [Models and Methods](#models-and-methods)
8. [Troubleshooting](#troubleshooting)
9. [API Reference](#api-reference)
10. [Examples](#examples)

---

## Project Overview

This project implements a comprehensive solution for forecasting anonymized time series data representing public equities. The system uses ensemble methods combining traditional statistical models, machine learning algorithms, and deep learning architectures to achieve robust generalization across different assets and time periods.

### Key Features

- **Multiple Model Types**: ARIMA, Prophet, XGBoost, CatBoost, LightGBM, Random Forest, LSTM, Transformer
- **Ensemble Approach**: Combines all models for improved robustness
- **Comprehensive Feature Engineering**: Lags, rolling statistics, technical indicators, seasonal features
- **Automatic Pipeline**: End-to-end automation with data generation, training, and reporting
- **Evaluation Metrics**: R², MAE, RMSE, MAPE
- **Full Documentation**: Detailed reports and visualizations

---

## Installation Guide

### Prerequisites

- Python 3.8 or higher
- Windows OS (batch files provided)
- Internet connection (for package installation)

### Step-by-Step Installation

1. **Install Python**
   - Download from https://www.python.org/downloads/
   - During installation, check "Add Python to PATH"
   - Restart computer after installation

2. **Get the Project**
   - Extract project files to desired location
   - Navigate to project directory

3. **Run Auto-Install**
   - Double-click `RUN_ME.bat`
   - This will automatically:
     - Detect Python
     - Install required packages
     - Create sample data
     - Run the pipeline

### Manual Installation

If you prefer manual installation:

```bash
# Install basic dependencies
pip install numpy pandas scikit-learn

# Install ML libraries (optional but recommended)
pip install xgboost catboost lightgbm

# Install deep learning (optional)
pip install torch tensorflow

# Install other utilities
pip install -r requirements.txt
```

---

## Quick Start

### Method 1: Automated (Recommended)

1. **Double-click `RUN_ME.bat`**
   - Everything happens automatically
   - Report will be generated in `reports/` folder
   - Report opens automatically when complete

### Method 2: Manual Steps

```bash
# 1. Generate sample data (if needed)
python create_simple_data.py

# 2. Run the pipeline
python generate_report.py

# 3. Check results
# Report saved to: reports/report_latest.txt
```

### Method 3: Using Jupyter Notebook

```bash
# Open Jupyter notebook
jupyter notebook train.ipynb

# Run all cells interactively
```

---

## Project Structure

```
Stream 2/
├── RUN_ME.bat                 # Main execution file (auto-installs & runs)
├── run.bat                    # Alternative batch file
├── generate_report.py         # Main report generator
├── pipeline.py                # Core pipeline class
├── config.py                  # Configuration settings
│
├── data/                      # Data directory
│   └── train.csv              # Training data
│
├── models/                    # Model implementations
│   ├── base_model.py          # Base class for all models
│   ├── traditional_models.py # ARIMA, Prophet
│   ├── ml_models.py          # XGBoost, CatBoost, LightGBM, RF
│   ├── deep_learning_models.py # LSTM, Transformer
│   └── ensemble_model.py     # Ensemble combining all models
│
├── utils/                     # Utility modules
│   ├── data_loader.py        # Data loading and validation
│   ├── feature_engineering.py # Feature creation
│   ├── evaluation.py          # Metrics calculation
│   └── visualization.py      # Plotting utilities
│
├── reports/                   # Generated reports
│   └── report_latest.txt      # Latest report
│
├── models/                    # Saved trained models
│   └── series_name/
│       └── model_name.pkl
│
├── train.ipynb               # Interactive training notebook
├── submit.py                 # Submission handler
├── requirements.txt          # Python dependencies
└── README.md                 # This file
```

---

## Usage Guide

### Running the Complete Pipeline

**Easiest Method:**
```bash
# Windows - Double-click
RUN_ME.bat

# Or from command line
RUN_ME.bat
```

**What Happens:**
1. Python detection and setup
2. Package installation (if needed)
3. Data creation (if missing)
4. Feature engineering
5. Model training
6. Model evaluation
7. Report generation
8. Results display

### Generating Sample Data

If you need to create sample data:

```bash
# Simple method (no dependencies needed)
python create_simple_data.py

# Full method (requires numpy/pandas)
python generate_sample_data.py
```

### Training Models

```python
from pipeline import TimeSeriesPipeline
from pathlib import Path

# Initialize pipeline
pipeline = TimeSeriesPipeline()

# Load data
pipeline.load_and_prepare_data(Path("data/train.csv"))

# Train models (happens automatically per series)
# Models are saved to models/ folder
```

### Generating Predictions

```python
from submit import generate_predictions

# Load trained models and generate predictions
submission = generate_predictions(
    pipeline=pipeline,
    test_data_path=Path("data/test.csv"),
    forecast_horizon=252
)
```

---

## Configuration

Edit `config.py` to customize:

### Model Configuration
```python
MODEL_CONFIG = {
    'forecast_horizon': 252,      # Days to forecast ahead
    'validation_split': 0.2,     # Fraction for validation
    'lookback_window': 60,        # Historical days to use
    'random_seed': 42,            # Random seed for reproducibility
}
```

### Feature Configuration
```python
FEATURE_CONFIG = {
    'lags': [1, 2, 3, 5, 7, 14, 21, 30, 60],  # Lag periods
    'rolling_windows': [7, 14, 30, 60, 90],   # Rolling windows
    'technical_indicators': True,              # Enable indicators
    'seasonality': True,                       # Enable seasonal features
}
```

### Model Hyperparameters
```python
MODEL_PARAMS = {
    'xgboost': {
        'n_estimators': 1000,
        'max_depth': 6,
        'learning_rate': 0.01,
        # ... more params
    },
    # ... other models
}
```

---

## Models and Methods

### Traditional Models

**ARIMA**
- Auto-regressive Integrated Moving Average
- Captures trend and autocorrelation
- Best for: Stationary time series

**Prophet**
- Facebook's time series forecasting tool
- Handles seasonality and holidays
- Best for: Series with strong seasonal patterns

### Machine Learning Models

**XGBoost**
- Gradient boosting framework
- Handles non-linear patterns
- Fast and efficient

**CatBoost**
- Gradient boosting with categorical support
- Robust to overfitting
- Good default hyperparameters

**LightGBM**
- Fast gradient boosting
- Low memory usage
- Excellent for large datasets

**Random Forest**
- Ensemble of decision trees
- Non-parametric
- Good baseline model

### Deep Learning Models

**LSTM**
- Long Short-Term Memory networks
- Captures long-term dependencies
- Best for: Complex temporal patterns

**Transformer**
- Attention-based architecture
- Captures temporal relationships
- State-of-the-art performance

### Ensemble

**Weighted Average Ensemble**
- Combines all trained models
- Equal weights (default)
- Reduces individual model errors

---

## Troubleshooting

### Python Not Found

**Error:** `Python not found`

**Solutions:**
1. Install Python from python.org
2. Check "Add Python to PATH" during installation
3. Restart computer after installation
4. Try editing batch file to use `py` instead of `python`

### Missing Dependencies

**Error:** `ModuleNotFoundError: No module named 'catboost'`

**Solutions:**
1. Run `pip install -r requirements.txt`
2. Or use `RUN_ME.bat` which auto-installs
3. Or install individually: `pip install catboost`

### Data Generation Fails

**Error:** `Failed to generate sample data`

**Solutions:**
1. Check Python is working: `python --version`
2. Install basic packages: `pip install numpy pandas`
3. Check write permissions in project folder
4. Try running as Administrator

### Models Not Training

**Error:** `No models available to train`

**Solutions:**
1. Install scikit-learn: `pip install scikit-learn`
2. Check that data file exists: `data/train.csv`
3. Verify data has enough rows (minimum ~100)

### Report Not Generated

**Solutions:**
1. Check `reports/` folder for timestamped files
2. Check console output for errors
3. Run `python diagnose_error.bat`
4. Check Python output for import errors

---

## API Reference

### TimeSeriesPipeline

Main pipeline class for training and evaluation.

#### Methods

**`load_and_prepare_data(data_path, series_columns=None)`**
- Loads time series data from CSV
- Parameters:
  - `data_path`: Path to CSV file
  - `series_columns`: List of column names (auto-detect if None)

**`train_models(series_name, X_train, y_train, X_val=None, y_val=None)`**
- Trains all available models for a series
- Parameters:
  - `series_name`: Name of the series
  - `X_train`, `y_train`: Training features and targets
  - `X_val`, `y_val`: Validation data (optional)

**`predict(series_name, X, model_name='ensemble')`**
- Makes predictions for a series
- Parameters:
  - `series_name`: Name of the series
  - `X`: Features for prediction
  - `model_name`: Model to use (default: 'ensemble')

**`evaluate_all_models(series_name, X_test, y_test)`**
- Evaluates all models
- Returns: Dictionary of metrics per model

**`save_models(output_dir=None)`**
- Saves trained models to disk
- Models saved as `.pkl` files

---

## Examples

### Example 1: Quick Run

```bash
# Just double-click
RUN_ME.bat

# Results in reports/report_latest.txt
```

### Example 2: Custom Configuration

```python
from pipeline import TimeSeriesPipeline
from config import MODEL_CONFIG

# Modify config
MODEL_CONFIG['lookback_window'] = 90  # Use 90 days instead of 60

# Run pipeline
from pipeline import run_pipeline
pipeline = run_pipeline(Path("data/train.csv"))
```

### Example 3: Single Model Training

```python
from models.ml_models import RandomForestForecaster

# Create and train single model
model = RandomForestForecaster(n_estimators=200)
model.fit(X_train, y_train)

# Make predictions
predictions = model.predict(X_test)
```

### Example 4: Custom Features

```python
from utils.feature_engineering import create_all_features

# Modify feature config
FEATURE_CONFIG['lags'] = [1, 7, 30]  # Only use these lags
FEATURE_CONFIG['technical_indicators'] = False  # Disable indicators

# Create features
df_features = create_all_features(df, target_col, FEATURE_CONFIG)
```

---

## Report Format

Reports include:

1. **Data Summary**
   - Series statistics
   - Date ranges
   - Data quality

2. **Model Training Results**
   - Training progress per model
   - Success/failure status

3. **Performance Metrics**
   - R² Score (primary)
   - MAE, RMSE, MAPE
   - Per-series and aggregated

4. **Best Models**
   - Best model per series
   - Overall best model

5. **Configuration**
   - Settings used
   - Hyperparameters

---

## Best Practices

1. **Data Preparation**
   - Ensure sufficient data (minimum 500+ days)
   - Handle missing values
   - Check for outliers

2. **Model Selection**
   - Start with simpler models (Random Forest)
   - Add complexity gradually
   - Use ensemble for production

3. **Evaluation**
   - Use temporal validation splits
   - Evaluate on out-of-sample data
   - Consider multiple metrics

4. **Deployment**
   - Save trained models
   - Monitor prediction quality
   - Retrain periodically

---

## Support

For issues:
1. Check `TROUBLESHOOTING.md`
2. Run `diagnose_error.bat`
3. Check report files for details
4. Review console output for errors

---

## License

This project is provided for educational and competition purposes.

---

**Last Updated:** November 2025  
**Version:** 1.0

